import { useEffect, useState, type ReactNode } from "react";
import { api } from "../api/api";
import SplashScreen from "../components/SplashScreen";
import { AuthContext, type User } from "./AuthContext";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isLoading, setIsLoading] = useState(true);

  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);

  const refresh = async () => {
    try {
      console.log("Getting Refresh Data");
      const response = await api.post("/auth/refresh");
      console.log("Refresh response received:", response.data);

      console.log(`${response.data.user.name} - found and recieved`);
      setUser(response.data.user);
      setAccessToken(response.data.accessToken);
      console.log(`User Loaded`);
    } catch (error) {
      setUser(null);
      setAccessToken(null);
      console.log("Refresh Completed, User not found. Setting to NULL");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  if (isLoading) return <SplashScreen />;

  return (
    <AuthContext.Provider
      value={{
        isLoading,
        user,
        accessToken,
        setUser,
        setAccessToken,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
